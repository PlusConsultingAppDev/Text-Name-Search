﻿using System;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using System.Collections.Generic;
using System.Text.RegularExpressions;

namespace NameSearch.EmployeeEngagement
{
    public class PreSelectedName
    {
        public string FirstName { get; set; }
        public string MiddleName { get; set; }
        public string LastName { get; set; }

        public string FullName
        {
            get { return String.Format("{0} {1}", FirstName, LastName); }
        }
    }

    public class NamesCount
    {
        public string Name { get; set; }
        public int Count { get; set; }
    }

    public class Engagement
    {

        public List<PreSelectedName> PreSelectedNames { get; set; }
        public String NewsPaperText { get; set; }
        public List<NamesCount> NamesCountOutput { get; set; }

        public Engagement()
        {
            ReadPreSelectedEmployeeNames();
            ReadNewsPaperText();
            NamesCountOutput = new List<NamesCount>();
        }

        private void ReadPreSelectedEmployeeNames()
        {
            //beacause this list gets updated weekly, in real life this could be read from a text file or the database. 
            //for brevity, implementing it this way
            List<PreSelectedName> preSelNames = new List<PreSelectedName>();
            preSelNames.Add(new PreSelectedName { FirstName = "Connor", MiddleName = "Gary", LastName = "Smith" });
            preSelNames.Add(new PreSelectedName { FirstName = "David", MiddleName = "Warren", LastName = "Black" });
            preSelNames.Add(new PreSelectedName { FirstName = "Seth", MiddleName = "David", LastName = "Greenly" });
            PreSelectedNames = preSelNames;
            //return preSelNames;
        }

        private void ReadNewsPaperText()
        {
            //same as above, it real life, this needs to be read from a file through the IO operations 
            string text = @"Lorem ipsum dolor sit amet, consectetur adipiscing elit. Maecenas Connor Smith dignissim erat consequat, placerat erat in, lobortis nulla. Vestibulum scelerisque magna ut urna hendrerit, finibus rutrum dolor faucibus. Seth David Greenly Aliquam feugiat urna vel tellus congue, non dictum orci varius. Vivamus tristique, lorem ut hendrerit aliquet, nulla nisl eleifend quam, sed laoreet erat lorem non diam. Nulla facilisi. Etiam bibendum Seth D. Greenly nec diam sed vestibulum. Nunc ipsum enim, imperdiet eu feugiat vel, vestibulum a justo. Donec efficitur velit porta odio consequat viverra. Quisque in tristique enim, sed euismod purus. Nullam eu leo pellentesque, porta leo in, maximus risus. Morbi in risus id risus feugiat egestas. David Black Nunc egestas, metus at volutpat tempus, massa justo venenatis arcu, a ornare mauris arcu at justo. Sed accumsan, David W. Black erat vitae euismod facilisis, risus odio bibendum neque, sit amet tincidunt diam ante et dolor. Morbi leo felis, posuere id ex ut, varius ornare libero.
                Suspendisse lacus ipsum, molestie vel nulla id, commodo hendrerit est. Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. Maecenas finibus magna libero, vehicula David Black luctus lorem varius non. Integer ut tempor massa, eget sollicitudin purus. Mauris efficitur in ipsum eu consectetur. Aliquam vitae nulla vitae sapien laoreet vehicula et et ex. Donec molestie auctor lorem eget rhoncus. Donec ornare sapien in turpis auctor, ut commodo David Warren Black augue cursus. Pellentesque fermentum nunc turpis, eu vulputate Connor Smith leo aliquet eu. Nam quis pretium felis. Sed id turpis sed lacus malesuada pulvinar et eget leo. Vestibulum eget dapibus mi. Duis tempor nec tellus vitae aliquet. Nam sapien massa, ornare non posuere sit amet, cursus a velit. Curabitur nec consectetur metus. Donec porttitor at libero a blandit.
                Proin luctus augue sit amet sem varius ultricies. Vestibulum nibh ligula, sollicitudin ac lectus eu, congue imperdiet quam. Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. Nulla ac nisl sed risus tincidunt finibus. Curabitur viverra eget justo non dignissim. Proin varius malesuada enim non vulputate. Integer fermentum interdum felis, luctus commodo nisi pulvinar quis.
                Donec pharetra faucibus urna a semper. Morbi tempor maximus Connor G Smith lectus sit amet interdum. Integer pretium ut est non vulputate. Aliquam pulvinar turpis laoreet dictum ultrices. Aenean diam metus, semper at quam et, iaculis viverra ante. Sed efficitur lorem quis consectetur mollis. Vivamus ut purus mauris. Quisque at gravida dolor. Fusce congue magna enim, ut placerat est porttitor a. Phasellus rutrum, neque lacinia cursus mattis, est lacus placerat nunc, a ornare enim nunc at justo. Sed urna leo, tincidunt elementum consequat vel, condimentum sed lacus.";
            NewsPaperText = text;
            //return text;
        }

        public void SearchForEmployeeNames()
        {

            //loop through the list of Pre Selected Names and search for the names in the text. if found, add them to the NamesCount list
            foreach (PreSelectedName preSelName in PreSelectedNames)
            {

                string pattern = String.Format("(?i)(?s){0}.*?{1}", preSelName.FirstName, preSelName.LastName);

                int ct = Regex.Matches(NewsPaperText, pattern, RegexOptions.IgnoreCase).Count; //.*?{2}");


                //ct = (text.Length - text.Replace(preSelName.LastName,"").Length) / preSelName.FirstName.Length;
                NamesCountOutput.Add(new NamesCount { Name = preSelName.FullName, Count = ct });

            }

            //print the names and the # occurances to the console.
            // in real world, this can be stored in the database to analyze data every week/month to check for trends 
            Console.WriteLine("Employee Name    Number of Occurances");
            Console.WriteLine("-------------------------------------");
            foreach (NamesCount nameCount in NamesCountOutput)
            {
                Console.WriteLine("{0} \t {1}", nameCount.Name, nameCount.Count);
                Console.WriteLine();
            }
        }

    }
}
