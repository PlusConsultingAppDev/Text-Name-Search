﻿using System;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Collections.Generic;
using NameSearch.EmployeeEngagement;

namespace NameSearch
{
    class Program
    {

        //main method
        static void Main(string[] args)
        {
            List<NamesCount> namesCount = new List<NamesCount>();

            //instantiate a new object of the type EmployeeEngagement
            Engagement empEng = new Engagement();
            //search for the employees and output results to the console
            empEng.SearchForEmployeeNames();

        }
    }
}
