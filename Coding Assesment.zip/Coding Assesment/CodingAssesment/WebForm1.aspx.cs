﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace CodingAssesment
{
    public partial class WebForm1 : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void txtBxSearch_Click(object sender, EventArgs e)
        {
            int connorSmithOccurance = 0;
            int connorGSmithOccurance = 0;
            int connorGPeriodSmithOccurance = 0;
            int connorGarySmithOccurance = 0;

            int sethGreenlyOccurance = 0;
            int sethDGreenlyOccurance = 0;
            int sethDPeriodGreenlyOccurance = 0;
            int sethDavidGreenlyOccurance = 0;

            int davidBlackOccurance = 0;
            int davidWBlackOccurance = 0;
            int davidWPeriodBlackOccurance = 0;
            int davidWarrenBlackOccurance = 0;
            char[] splitBy = { ' ' };
            string x = txtBxContent.Text;
            List<string> names = x.Split(splitBy).ToList();
            for (int i = 0; i < names.Count ; i++)
            {
                if (names[i].ToLower() == "connor")
                {
                    if (names[i + 1].ToLower() == "smith")
                    {
                        connorSmithOccurance = connorSmithOccurance + 1;
                    }
                }
                else if (names[i].ToLower() == "connor")
                {
                    if (names[i + 1].ToLower() == "g")
                    {
                        if (names[i + 2].ToLower() == "smith")
                        {
                            connorGSmithOccurance = connorGSmithOccurance + 1;
                        }
                    }
                }
                if (names[i].ToLower() == "connor")
                {
                    if (names[i + 1].ToLower() == "g.")
                    {
                        if (names[i + 2].ToLower() == "smith")
                        {
                            connorGPeriodSmithOccurance = connorGPeriodSmithOccurance + 1;
                        }
                    }
                }
                if (names[i].ToLower() == "connor")
                {
                    if (names[i+1].ToLower() == "gary")
                    {
                        if (names[i + 2].ToLower()== "smith")
                        {
                            connorGarySmithOccurance = connorGarySmithOccurance + 1;
                        }
                    }
                }



                if (names[i].ToLower() == "seth")
                {                   
                        if (names[i+1].ToLower() == "greenly")
                        {
                            sethGreenlyOccurance = sethGreenlyOccurance + 1;
                        }                    
                }
                if (names[i].ToLower() == "seth")
                {
                    if (names[i+1].ToLower() == "d")
                    {
                        if (names[i+2].ToLower() == "greenly")
                        {
                            sethDGreenlyOccurance = sethDGreenlyOccurance + 1;
                        }
                    }
                }
                if (names[i].ToLower() == "seth")
                {
                    if (names[i+1].ToLower() == "d.")
                    {
                        if (names[i+2].ToLower() == "greenly")
                        {
                            sethDPeriodGreenlyOccurance = sethDPeriodGreenlyOccurance + 1;
                        }
                    }
                }
                if (names[i].ToLower() == "seth")
                {
                    if (names[i+1].ToLower() == "david")
                    {
                        if (names[i+2].ToLower() == "greenly")
                        {
                            sethDavidGreenlyOccurance = sethDavidGreenlyOccurance + 1;
                        }
                    }
                }



                
                if (names[i].ToLower() == "david")
                {                    
                        if (names[i+1].ToLower() == "black")
                        {
                            davidBlackOccurance = davidBlackOccurance + 1;
                        }                    
                }
                if (names[i].ToLower() == "david")
                {
                    if (names[i+1].ToLower() == "w")
                    {
                        if (names[i+2].ToLower() == "black")
                        {
                            davidWBlackOccurance = davidWBlackOccurance + 1;
                        }
                    }
                }
                if (names[i].ToLower() == "david")
                {
                    if (names[i+1].ToLower() == "w.")
                    {
                        if (names[i+2].ToLower() == "black")
                        {
                            davidWPeriodBlackOccurance = davidWPeriodBlackOccurance + 1;
                        }
                    }
                }
                if (names[i].ToLower() == "david")
                {
                    if (names[i+1].ToLower() == "warren")
                    {
                        if (names[i+2].ToLower() == "black")
                        {
                            davidWarrenBlackOccurance = davidWarrenBlackOccurance + 1;
                        }
                    }
                }               
            }
            lstNoOfOccurances.Items.Clear();
            lstNoOfOccurances.Visible = true;

            lstNoOfOccurances.Items.Add("Connor Smith Occurance("+connorSmithOccurance+")");
            lstNoOfOccurances.Items.Add("Connor G Smith Occurance(" + connorGSmithOccurance + ")");
            lstNoOfOccurances.Items.Add("Connor G. Smith Occurance(" + connorGPeriodSmithOccurance + ")");
            lstNoOfOccurances.Items.Add("Connor Smith Gary Occurance(" + connorGarySmithOccurance + ")");

            lstNoOfOccurances.Items.Add("Seth  Greenly Occurance(" + sethGreenlyOccurance + ")");
            lstNoOfOccurances.Items.Add("Seth D Greenly Occurance(" + sethDGreenlyOccurance + ")");
            lstNoOfOccurances.Items.Add("Seth D. Greenly Occurance(" + sethDPeriodGreenlyOccurance + ")");
            lstNoOfOccurances.Items.Add("Seth David Greenly Occurance(" + sethDavidGreenlyOccurance + ")");

            lstNoOfOccurances.Items.Add("David  Black(" + davidBlackOccurance + ")");
            lstNoOfOccurances.Items.Add("David W Black(" + davidWBlackOccurance + ")");
            lstNoOfOccurances.Items.Add("David W. Black(" + davidWPeriodBlackOccurance + ")");
            lstNoOfOccurances.Items.Add("David Warren Black(" + davidWarrenBlackOccurance + ")");
        }
    }
}