﻿namespace TNSLibrary.Type {

    public class Email {
        public string EmailAddress { get; }

        public Email(string email) {
            EmailAddress = email;
        }
    }
}
