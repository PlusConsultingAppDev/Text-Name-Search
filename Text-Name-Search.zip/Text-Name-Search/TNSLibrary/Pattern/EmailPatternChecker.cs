﻿using System;
using TNSLibrary.Type;

namespace TNSLibrary.Pattern {

    public class EmailPatternChecker : IPatternChecker {

        public int MatchPatterns(Employee employee, string input) {
            throw new NotImplementedException();
        }

        public int MatchPatterns(Email email, string input) {
            throw new NotImplementedException();
        }
    }
}
